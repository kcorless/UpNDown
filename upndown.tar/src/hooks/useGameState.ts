import { useCallback } from 'react';
import { useGameStateContext } from '../contexts/GameStateContext';
import { useMultiplayer } from '../contexts/MultiplayerContext';
import { 
  type GameState, 
  PILE_TYPES, 
  START_VALUES,
  SOLITAIRE_HAND_SIZE 
} from '../types/gameTypes';
import { createDeck, drawCards, shuffleDeck } from '../utils/gameUtils';
import { createLobby, joinLobby, endTurn } from '../services/lobbyService';

export function useGameState() {
  const { state, dispatch } = useGameStateContext();
  const { dispatch: multiplayerDispatch } = useMultiplayer();

  const initializeGame = useCallback(async (
    playerId: string, 
    playerName: string,
    gameMode: 'solitaire' | 'multiplayer',
    isJoining: boolean = false,
    existingGameId?: string
  ) => {
    console.log(`Initializing ${gameMode} game for player:`, playerId);
    const timestamp = Date.now();

    if (gameMode === 'multiplayer') {
      try {
        let gameId: string;
        if (isJoining && existingGameId) {
          gameId = existingGameId;
          console.log('Joining existing game:', gameId);
          await joinLobby(gameId, playerId, playerName);
          multiplayerDispatch({
            type: 'JOIN_GAME',
            payload: {
              gameId,
              playerId,
              playerName
            }
          });
        } else {
          if (!existingGameId) {
            gameId = await createLobby(playerId, playerName);
          } else {
            gameId = existingGameId;
          }
          console.log('Created new game:', gameId);
          multiplayerDispatch({
            type: 'CREATE_GAME',
            payload: {
              gameId,
              hostId: playerId,
              hostName: playerName
            }
          });
        }

        const initialState: GameState = {
          gameId,
          gameMode: 'multiplayer',
          players: [{
            id: playerId,
            name: playerName,
            hand: [],
            cardCount: 0,
            isHost: !isJoining,
            isReady: false,
            joinedAt: timestamp,
            stats: {
              totalCardsPlayed: 0,
              specialPlaysCount: 0,
              totalMovement: 0
            }
          }],
          currentPlayer: 0,
          foundationPiles: [
            {
              id: 'up-1',
              type: PILE_TYPES.UP,
              cards: [],
              startValue: START_VALUES.UP,
              currentValue: START_VALUES.UP,
              label: 'UP 1'
            },
            {
              id: 'up-2',
              type: PILE_TYPES.UP,
              cards: [],
              startValue: START_VALUES.UP,
              currentValue: START_VALUES.UP,
              label: 'UP 2'
            },
            {
              id: 'down-1',
              type: PILE_TYPES.DOWN,
              cards: [],
              startValue: START_VALUES.DOWN,
              currentValue: START_VALUES.DOWN,
              label: 'DOWN 1'
            },
            {
              id: 'down-2',
              type: PILE_TYPES.DOWN,
              cards: [],
              startValue: START_VALUES.DOWN,
              currentValue: START_VALUES.DOWN,
              label: 'DOWN 2'
            }
          ],
          drawPile: [],
          cardsPlayedThisTurn: 0,
          minCardsPerTurn: 2,
          turnEnded: false,
          gameOver: false,
          gameWon: false,
          lastUpdate: timestamp
        };

        console.log('Initial multiplayer state:', initialState);
        dispatch({ type: 'START_GAME', payload: initialState });
      } catch (error) {
        console.error('Failed to initialize multiplayer game:', error);
      }
    } else {
      const deck = shuffleDeck(createDeck());
      const { newHand, newDeck } = drawCards(deck, [], SOLITAIRE_HAND_SIZE);
      
      const initialState: GameState = {
        gameId: `game-${timestamp}`,
        gameMode: 'solitaire',
        players: [{
          id: playerId,
          name: playerName,
          hand: newHand,
          cardCount: SOLITAIRE_HAND_SIZE,
          isHost: true,
          isReady: true,
          joinedAt: timestamp,
          stats: {
            totalCardsPlayed: 0,
            specialPlaysCount: 0,
            totalMovement: 0
          }
        }],
        currentPlayer: 0,
        foundationPiles: [
          {
            id: 'up-1',
            type: PILE_TYPES.UP,
            cards: [],
            startValue: START_VALUES.UP,
            currentValue: START_VALUES.UP,
            label: 'UP 1'
          },
          {
            id: 'up-2',
            type: PILE_TYPES.UP,
            cards: [],
            startValue: START_VALUES.UP,
            currentValue: START_VALUES.UP,
            label: 'UP 2'
          },
          {
            id: 'down-1',
            type: PILE_TYPES.DOWN,
            cards: [],
            startValue: START_VALUES.DOWN,
            currentValue: START_VALUES.DOWN,
            label: 'DOWN 1'
          },
          {
            id: 'down-2',
            type: PILE_TYPES.DOWN,
            cards: [],
            startValue: START_VALUES.DOWN,
            currentValue: START_VALUES.DOWN,
            label: 'DOWN 2'
          }
        ],
        drawPile: newDeck,
        cardsPlayedThisTurn: 0,
        minCardsPerTurn: 2,
        turnEnded: false,
        gameOver: false,
        gameWon: false,
        lastUpdate: timestamp
      };

      console.log('Initial solitaire state:', initialState);
      dispatch({ type: 'START_GAME', payload: initialState });
    }
  }, [dispatch, multiplayerDispatch]);

  const playCard = useCallback((cardIndex: number, pileId: string) => {
    console.log('Playing card:', cardIndex, 'on pile:', pileId);
    dispatch({ type: 'PLAY_CARD', payload: { cardIndex, pileId } });
  }, [dispatch]);

  const handleEndTurn = useCallback(async () => {
    if (!state.gameState || state.gameState.gameMode !== 'multiplayer') {
      console.log('Cannot end turn: not in multiplayer game');
      return;
    }

    const currentPlayer = state.gameState.players[state.gameState.currentPlayer];
    if (!currentPlayer) {
      console.log('Cannot end turn: no current player');
      return;
    }

    console.log('Ending turn for player:', currentPlayer.id);
    try {
      await endTurn(state.gameState.gameId, currentPlayer.id);
      dispatch({ type: 'END_TURN' });
    } catch (error) {
      console.error('Failed to end turn:', error);
    }
  }, [state.gameState, dispatch]);

  return {
    gameState: state.gameState,
    error: state.error,
    initializeGame,
    playCard,
    endTurn: handleEndTurn
  };
}