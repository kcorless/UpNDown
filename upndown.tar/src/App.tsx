import React, { useState } from 'react';
import { useGameState } from './hooks/useGameState';
import { SolitaireGame } from './components/game/SolitaireGame';
import { MultiplayerGame } from './components/game/MultiplayerGame';
import { GameMenu } from './components/game/GameMenu';
import { GameLobby } from './components/GameLobby';
import { MultiplayerSetup } from './components/MultiplayerSetup';
import './App.css';

const App: React.FC = () => {
  const { gameState, initializeGame } = useGameState();
  const [showMultiplayerSetup, setShowMultiplayerSetup] = useState(false);

  const handleStartGame = (gameMode: 'solitaire' | 'multiplayer') => {
    if (gameMode === 'multiplayer') {
      setShowMultiplayerSetup(true);
    } else {
      const playerId = 'player1';
      const playerName = 'Player 1';
      initializeGame(playerId, playerName, gameMode);
    }
  };

  const handleCreateGame = async (gameId: string) => {
    const playerId = 'player1';
    const playerName = 'Player 1';
    await initializeGame(playerId, playerName, 'multiplayer', false, gameId);
    setShowMultiplayerSetup(false);  // Add this line to close setup screen
};

  const handleJoinGame = async (gameId: string) => {
    const playerId = 'player2';
    const playerName = 'Player 2';
    await initializeGame(playerId, playerName, 'multiplayer', true, gameId);
  };

  const handleCancelMultiplayer = () => {
    setShowMultiplayerSetup(false);
  };

  return (
    <div className="App">
      {!gameState && !showMultiplayerSetup && <GameMenu onStartGame={handleStartGame} />}
      {!gameState && showMultiplayerSetup && (
        <MultiplayerSetup
          playerId="player1"
          playerName="Player 1"
          onCreateGame={handleCreateGame}
          onJoinGame={handleJoinGame}
          onCancel={handleCancelMultiplayer}
        />
      )}
      {gameState?.gameMode === 'solitaire' && <SolitaireGame />}
      {gameState?.gameMode === 'multiplayer' && gameState.players[0].isReady && <MultiplayerGame />}
      {gameState?.gameMode === 'multiplayer' && !gameState.players[0].isReady && <GameLobby />}
    </div>
  );
};

export default App;