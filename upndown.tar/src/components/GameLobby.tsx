import { type FC, useState, useEffect } from 'react';
import { useUI } from '../contexts/UIContext';
import { useMultiplayer } from '../contexts/MultiplayerContext';
import { useGameStateContext } from '../contexts/GameStateContext';
import { type Player } from '../types/gameTypes';
import { ref, onValue, off } from 'firebase/database';
import { database } from '../config/firebase';
import { startGame as startLobbyGame } from '../services/lobbyService';
import './GameLobby.css';

type LobbyStatus = 'waiting' | 'ready' | 'in_progress';

interface GameLobby {
  id: string;
  host: string;
  players: Record<string, Player>;
  status: LobbyStatus;
  maxPlayers: number;
  createdAt: number;
}

export const GameLobby: FC = () => {
  const { dispatch: uiDispatch } = useUI();
  const { state: multiplayerState } = useMultiplayer();
  const { state: { gameState }, dispatch: gameDispatch } = useGameStateContext();
  const [lobby, setLobby] = useState<GameLobby | null>(null);

  console.log('GameLobby rendering with multiplayerState:', multiplayerState);

  useEffect(() => {
    console.log('GameLobby useEffect triggered with gameId:', multiplayerState?.gameId);
    if (!multiplayerState?.gameId) {
      console.log('No gameId available, skipping lobby subscription');
      return;
    }

    const unsubscribe = subscribeToLobby(multiplayerState.gameId, (updatedLobby) => {
      console.log('Lobby update received:', updatedLobby);
      setLobby(updatedLobby);
      
      // Handle game start transition
      if (updatedLobby.status === 'in_progress' && gameState) {
        // Use the complete player data from the lobby
        const updatedPlayers = Object.values(updatedLobby.players);
        console.log('Player data during transition:', {
            updatedPlayers,
            currentPlayerId: multiplayerState?.connectedPlayers[0]?.id,
            lobbyData: updatedLobby,
            playerHands: updatedPlayers.map(p => ({ 
                playerId: p.id, 
                handSize: p.hand?.length,
                hand: p.hand
            }))
        });
        
        gameDispatch({
          type: 'UPDATE_GAME_STATE',
          payload: {
            ...gameState,
            players: updatedPlayers,
            gameId: updatedLobby.id,
            gameMode: 'multiplayer'
          }
        });
      }
    });

    return () => {
      console.log('Cleaning up lobby subscription');
      unsubscribe();
    };
  }, [multiplayerState?.gameId, gameDispatch, gameState]);

  const handleStartGame = async () => {
    if (!lobby || !multiplayerState?.connectedPlayers[0]?.id) {
      console.log('Cannot start game: missing lobby or player ID');
      return;
    }

    if (Object.keys(lobby.players).length < 2) {
      uiDispatch({
        type: 'ADD_NOTIFICATION',
        payload: {
          message: 'Need at least 2 players to start',
          type: 'error',
          duration: 3000
        }
      });
      return;
    }

    if (lobby.host !== multiplayerState.connectedPlayers[0].id) {
      uiDispatch({
        type: 'ADD_NOTIFICATION',
        payload: {
          message: 'Only the host can start the game',
          type: 'error',
          duration: 3000
        }
      });
      return;
    }

    try {
      console.log('Attempting to start game for lobby:', lobby.id);
      await startLobbyGame(lobby.id, multiplayerState.connectedPlayers[0].id);
    } catch (error) {
      console.error('Failed to start game:', error);
      uiDispatch({
        type: 'ADD_NOTIFICATION',
        payload: {
          message: 'Failed to start game',
          type: 'error',
          duration: 3000
        }
      });
    }
  };

  if (!lobby) {
    console.log('Rendering loading state - no lobby data available');
    return <div>Loading lobby...</div>;
  }

  // Convert players object to array for rendering
  const playersList = Object.entries(lobby.players).map(([id, player]) => ({
    ...player,
    id
  }));

  return (
    <div className="game-lobby">
      <h2>Game Lobby</h2>

      <div className="lobby-code">
        <h3>Game Code</h3>
        <p className="code">{lobby.id}</p>
        <p className="share-message">Share this code with other players to join</p>
      </div>

      <div className="lobby-info">
        <p>Host: {lobby.players[lobby.host]?.name}</p>
        <p>Players ({playersList.length}/{lobby.maxPlayers}):</p>
        <ul className="player-list">
          {playersList.map((player) => (
            <li key={player.id} className={player.id === lobby.host ? 'host' : ''}>
              {player.name} {player.id === lobby.host && '(Host)'}
            </li>
          ))}
        </ul>
      </div>
      {lobby.host === multiplayerState?.connectedPlayers[0]?.id && (
        <button
          onClick={handleStartGame}
          disabled={playersList.length < 2 || lobby.status === 'in_progress'}
        >
          Start Game
        </button>
      )}
    </div>
  );
};

function subscribeToLobby(lobbyId: string, callback: (lobby: GameLobby) => void): () => void {
  console.log('Setting up lobby subscription for:', lobbyId);
  const lobbyRef = ref(database, `lobbies/${lobbyId}`);
  
  const onLobbyUpdate = (snapshot: any) => {
    console.log('Firebase snapshot received:', snapshot.val());
    if (snapshot.exists()) {
      callback(snapshot.val());
    }
  };

  onValue(lobbyRef, onLobbyUpdate);

  return () => {
    console.log('Cleaning up lobby subscription');
    off(lobbyRef, 'value', onLobbyUpdate);
  };
}