import { type FC, useEffect } from 'react';
import { useGameState } from '../../hooks/useGameState';
import { Card } from '../card/Card';
import { CardPile } from '../CardPile';
import './SolitaireGame.css';

export const SolitaireGame: FC = () => {
  const { gameState, playCard, initializeGame } = useGameState();

  useEffect(() => {
    if (!gameState) {
      console.log('Initializing new solitaire game');
      initializeGame('player1', 'Player 1', 'solitaire');
    }
  }, [gameState, initializeGame]);

  if (!gameState || gameState.gameMode !== 'solitaire') {
    return <div className="loading">Loading game...</div>;
  }

  const player = gameState.players[0];
  
  const handleCardDrop = (pileId: string) => (cardId: string): void => {
    const cardIndex = player.hand.findIndex((c) => c.id === cardId);
    if (cardIndex !== -1) {
      console.log(`Attempting to play card ${cardId} on pile ${pileId}`);
      playCard(cardIndex, pileId);
    }
  };

  const renderGameStats = () => {
    const { stats } = player;
    return (
      <div className="game-stats">
        <h3>Game Statistics</h3>
        <div className="stats-grid">
          <div className="stat-item">
            <span className="stat-label">Total Cards Played:</span>
            <span className="stat-value">{stats.totalCardsPlayed}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Special Plays (+10/-10):</span>
            <span className="stat-value">{stats.specialPlaysCount}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Total Card Movement:</span>
            <span className="stat-value">{stats.totalMovement}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Average Movement per Card:</span>
            <span className="stat-value">
              {stats.totalCardsPlayed > 0 
                ? (stats.totalMovement / stats.totalCardsPlayed).toFixed(1)
                : '0'}
            </span>
          </div>
        </div>
      </div>
    );
  };

  const renderGameOverMessage = () => {
    if (!gameState.gameOver) return null;

    return (
      <div className="game-over-overlay">
        <div className="game-over-message">
          <h2>{gameState.gameWon ? 'Congratulations!' : 'Game Over'}</h2>
          <p>
            {gameState.gameWon 
              ? 'You successfully played all cards! Well done!' 
              : 'No more valid moves available!'}
          </p>
          {renderGameStats()}
          <button 
            className="new-game-button"
            onClick={() => initializeGame('player1', 'Player 1', 'solitaire')}
          >
            Play Again
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="solitaire-game">
      {renderGameOverMessage()}

      <h1 className="game-title">Up-N-Down Solitaire</h1>

      <div className="foundation-piles">
        {gameState.foundationPiles.map((pile) => (
          <CardPile
            key={pile.id}
            pile={pile}
            onCardDrop={handleCardDrop(pile.id)}
          />
        ))}
      </div>
      
      <div className="draw-pile-counter">
        {gameState.drawPile.length}
      </div>

      <div className="hand-section">
        <div className="hand-cards">
          {player.hand.map((card) => (
            <Card
              key={card.id}
              card={card}
              draggable={true}
              onClick={() => {
                console.log('Card clicked:', card);
              }}
            />
          ))}
        </div>
        <h3 className="hand-label">Your Hand ({player.hand.length} cards)</h3>
      </div>
    </div>
  );
};