import { type FC } from 'react';
import { useGameState } from '../../hooks/useGameState';
import { useMultiplayer } from '../../contexts/MultiplayerContext';
import { Card } from '../card/Card';
import { CardPile } from '../CardPile';
import './SolitaireGame.css';

export const MultiplayerGame: FC = () => {
  const { gameState, playCard, endTurn } = useGameState();
  const { state: multiplayerState } = useMultiplayer();

  console.log('MultiplayerGame rendering with gameState:', gameState);

  if (!gameState || gameState.gameMode !== 'multiplayer') {
    console.log('Game state not ready:', { gameState });
    return <div className="loading">Loading game state...</div>;
  }

  const currentPlayerId = multiplayerState?.connectedPlayers[0]?.id;
  const activePlayer = gameState.players[gameState.currentPlayer];
  const viewingPlayer = gameState.players.find(p => p.id === currentPlayerId);
  
  if (!viewingPlayer || !viewingPlayer.hand) {
    console.log('Current player not ready:', { viewingPlayer });
    return <div className="loading">Loading game state...</div>;
  }
  
  const handleCardDrop = (pileId: string) => (cardId: string): void => {
    if (viewingPlayer.id === activePlayer.id) {
      const cardIndex = viewingPlayer.hand.findIndex((c) => c.id === cardId);
      if (cardIndex !== -1) {
        playCard(cardIndex, pileId);
      }
    }
  };

  const handleEndTurn = () => {
    console.log('Handling end turn');
    endTurn();
  };

  const canEndTurn = gameState.cardsPlayedThisTurn >= gameState.minCardsPerTurn;
  const isPlayerTurn = viewingPlayer.id === activePlayer.id;

  return (
    <div className="solitaire-game">
      <h1 className="game-title">Up-N-Down Multiplayer</h1>

      <div className="foundation-piles">
        {gameState.foundationPiles.map((pile) => (
          <CardPile
            key={pile.id}
            pile={pile}
            onCardDrop={handleCardDrop(pile.id)}
          />
        ))}
      </div>

      <div className="draw-pile-counter">
        {gameState.drawPile.length}
      </div>

      <div className="hand-section">
        <div className="hand-cards">
          {viewingPlayer.hand.map((card) => (
            <Card
              key={card.id}
              card={card}
              draggable={isPlayerTurn}
            />
          ))}
        </div>
        <h3 className="hand-label">Your Hand ({viewingPlayer.hand.length} cards)</h3>
      </div>

      <div className="turn-management">
        <div className="current-turn-info">
          <p>Current Player: {activePlayer.name}</p>
          <p>{isPlayerTurn ? "Your turn" : `Waiting for ${activePlayer.name}`}</p>
          {isPlayerTurn && (
            <p>Cards Played This Turn: {gameState.cardsPlayedThisTurn} / {gameState.minCardsPerTurn}</p>
          )}
        </div>
        {isPlayerTurn && canEndTurn && (
          <button 
            className="end-turn-button"
            onClick={handleEndTurn}
          >
            End Turn
          </button>
        )}
      </div>
    </div>
  );
};