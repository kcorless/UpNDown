import { database } from '../config/firebase';
import { 
    ref, 
    set, 
    get, 
    update,
    onValue,
    off,
    child,
    runTransaction
} from 'firebase/database';
import { type Player } from '../types/gameTypes';
import { dealMultiplayerHands, createDeck } from '../utils/gameUtils';

interface GameLobby {
    id: string;
    host: string;
    players: Record<string, Player>;
    status: 'waiting' | 'ready' | 'starting' | 'in_progress';
    createdAt: number;
    maxPlayers: number;
    currentPlayer?: number;
}

const LOBBY_PATH = 'lobbies';
const MAX_PLAYERS = 4;

const debugDatabase = async (path: string) => {
    try {
        const dbRef = ref(database);
        const snapshot = await get(child(dbRef, path));
        console.log(`Database content at ${path}:`, snapshot.val());
    } catch (error) {
        console.error(`Error reading database at ${path}:`, error);
    }
};

export const generateGameId = (): string => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
};

export const createLobby = async (hostId: string, hostName: string): Promise<string> => {
    try {
        console.log('Creating lobby with host:', { hostId, hostName });
        const gameId = generateGameId();
        
        const hostPlayer: Player = {
            id: hostId,
            name: hostName || 'Host',
            isReady: false,
            isHost: true,
            joinedAt: Date.now(),
            cardCount: 0,
            hand: [],
            stats: {
                totalCardsPlayed: 0,
                specialPlaysCount: 0,
                totalMovement: 0
            }
        };
        
        const lobby: GameLobby = {
            id: gameId,
            host: hostId,
            players: {
                [hostId]: hostPlayer
            },
            status: 'waiting',
            createdAt: Date.now(),
            maxPlayers: MAX_PLAYERS,
            currentPlayer: 0
        };

        console.log('Writing to database path:', `${LOBBY_PATH}/${gameId}`);
        const lobbyRef = ref(database, `${LOBBY_PATH}/${gameId}`);
        
        const snapshot = await get(lobbyRef);
        if (snapshot.exists()) {
            console.log('Game ID collision, generating new ID');
            return createLobby(hostId, hostName);
        }

        await set(lobbyRef, lobby);
        console.log('Successfully created lobby:', lobby);
        
        await debugDatabase(`${LOBBY_PATH}/${gameId}`);
        
        return gameId;
    } catch (error) {
        console.error('Error creating lobby:', error);
        throw error;
    }
};

export const joinLobby = async (gameId: string, playerId: string, playerName: string): Promise<void> => {
    try {
        console.log('Attempting to join lobby:', { gameId, playerId, playerName });
        const lobbyRef = ref(database, `${LOBBY_PATH}/${gameId}`);
        
        const snapshot = await get(lobbyRef);
        console.log('Initial lobby check - exists:', snapshot.exists(), 'value:', snapshot.val());
        
        if (!snapshot.exists()) {
            throw new Error(`Game not found: ${gameId}`);
        }

        const currentData = snapshot.val() as GameLobby;
        
        if (currentData.players[playerId]) {
            console.log('Player already in lobby, updating name if changed');
            if (currentData.players[playerId].name !== playerName) {
                await update(ref(database, `${LOBBY_PATH}/${gameId}/players/${playerId}`), {
                    name: playerName
                });
            }
            return;
        }

        const currentPlayerCount = Object.keys(currentData.players).length;
        if (currentPlayerCount >= MAX_PLAYERS) {
            throw new Error('Game is full');
        }

        const newPlayer: Player = {
            id: playerId,
            name: playerName,
            isReady: false,
            isHost: false,
            joinedAt: Date.now(),
            cardCount: 0,
            hand: [],
            stats: {
                totalCardsPlayed: 0,
                specialPlaysCount: 0,
                totalMovement: 0
            }
        };

        await update(ref(database, `${LOBBY_PATH}/${gameId}/players/${playerId}`), newPlayer);
        console.log('Successfully added player to lobby:', newPlayer);

    } catch (error) {
        console.error('Error joining lobby:', error);
        throw error;
    }
};

export const endTurn = async (gameId: string, currentPlayerId: string): Promise<void> => {
    try {
        console.log('Ending turn for game:', { gameId, playerId: currentPlayerId });
        const lobbyRef = ref(database, `${LOBBY_PATH}/${gameId}`);
        
        await runTransaction(lobbyRef, (currentData: GameLobby | null) => {
            if (!currentData) {
                console.log('No game found for turn end');
                throw new Error('Game not found');
            }

            console.log('Current game state before turn end:', currentData);
            
            const playerIds = Object.keys(currentData.players);
            const currentPlayerIndex = playerIds.findIndex(id => id === currentPlayerId);
            
            if (currentPlayerIndex === -1) {
                console.log('Current player not found in game');
                throw new Error('Player not found');
            }

            const nextPlayerIndex = (currentPlayerIndex + 1) % playerIds.length;
            console.log('Turn transition:', {
                currentPlayerIndex,
                nextPlayerIndex,
                playerIds
            });

            currentData.currentPlayer = nextPlayerIndex;
            console.log('Updated game state after turn end:', currentData);
            return currentData;
        });

        console.log('Successfully ended turn');
        await debugDatabase(`${LOBBY_PATH}/${gameId}`);

    } catch (error) {
        console.error('Error ending turn:', error);
        throw error;
    }
};

export const leaveLobby = async (gameId: string, playerId: string): Promise<void> => {
    try {
        console.log('Player leaving lobby:', { gameId, playerId });
        const lobbyRef = ref(database, `${LOBBY_PATH}/${gameId}`);
        
        await runTransaction(lobbyRef, (currentData: GameLobby | null) => {
            if (!currentData) {
                console.log('No lobby found to leave');
                return null;
            }

            const { [playerId]: removedPlayer, ...remainingPlayers } = currentData.players;
            
            if (Object.keys(remainingPlayers).length === 0) {
                console.log('No players left, removing lobby');
                return null;
            }

            if (removedPlayer?.isHost) {
                const newHostId = Object.keys(remainingPlayers)[0];
                remainingPlayers[newHostId].isHost = true;
                currentData.host = newHostId;
            }

            currentData.players = remainingPlayers;
            return currentData;
        });

        console.log('Successfully processed player leaving lobby');

    } catch (error) {
        console.error('Error leaving lobby:', error);
        throw error;
    }
};

export const setPlayerReady = async (gameId: string, playerId: string, isReady: boolean): Promise<void> => {
    try {
        console.log('Setting player ready status:', { gameId, playerId, isReady });
        const playerRef = ref(database, `${LOBBY_PATH}/${gameId}/players/${playerId}`);
        
        await runTransaction(playerRef, (currentData: Player | null) => {
            if (!currentData) return null;
            return { ...currentData, isReady };
        });

    } catch (error) {
        console.error('Error setting player ready status:', error);
        throw error;
    }
};

export const startGame = async (gameId: string, playerId: string): Promise<void> => {
    try {
        console.log('Starting game:', { gameId, playerId });
        const lobbyRef = ref(database, `${LOBBY_PATH}/${gameId}`);
        
        await runTransaction(lobbyRef, (currentData: GameLobby | null) => {
            if (!currentData) {
                throw new Error('Game not found');
            }

            if (currentData.host !== playerId) {
                throw new Error('Only the host can start the game');
            }

            const playerIds = Object.keys(currentData.players);
            const initialDeck = createDeck();
            console.log('Initial Deck:', initialDeck);
            const { player1Hand, player2Hand } = dealMultiplayerHands(initialDeck);

            console.log('Dealing hands:', { player1Hand, player2Hand });

            playerIds.forEach((id, index) => {
                if (currentData.players[id]) {
                    currentData.players[id] = {
                        ...currentData.players[id],
                        hand: index === 0 ? player1Hand : player2Hand,
                        cardCount: index === 0 ? player1Hand.length : player2Hand.length,
                        isReady: true
                    };
                    console.log(`Updated player ${id} hand:`, currentData.players[id].hand);
                }
            });

            currentData.status = 'in_progress';
            currentData.currentPlayer = 0;  // Ensure first player starts
            
            return currentData;
        });

        console.log('Successfully started game');

    } catch (error) {
        console.error('Error starting game:', error);
        throw error;
    }
};

export const subscribeLobby = (gameId: string, callback: (lobby: GameLobby | null) => void): (() => void) => {
    console.log('Setting up lobby subscription:', gameId);
    const lobbyRef = ref(database, `${LOBBY_PATH}/${gameId}`);

    const onLobbyUpdate = (snapshot: any) => {
        const data = snapshot.val();
        console.log('Lobby update received:', data);
        if (data?.currentPlayer !== undefined) {
            console.log('Current player in lobby:', {
                playerIndex: data.currentPlayer,
                playerId: Object.keys(data.players)[data.currentPlayer]
            });
        }
        callback(data);
    };

    onValue(lobbyRef, onLobbyUpdate);

    return () => {
        console.log('Cleaning up lobby subscription');
        off(lobbyRef, 'value', onLobbyUpdate);
    };
};