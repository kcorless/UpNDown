export const SESSION_KEYS = {
    GAME_MODE: 'upndown_game_mode',
    GAME_ID: 'upndown_game_id',
    PLAYER_ID: 'upndown_player_id',
    PLAYER_NAME: 'upndown_player_name'
} as const;
